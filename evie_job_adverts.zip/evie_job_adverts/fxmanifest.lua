fx_version 'cerulean'
game 'gta5'

author 'Evie'
description 'Business job advertisement system'
version '1.0.1'

shared_scripts {
    '@ox_lib/init.lua',
    'config.lua'
}

escrow_ignore {
    'config.lua',
    'server.lua',
    'client.lua',
    'fxmanifest.lua'
}

server_script 'server.lua'
client_script 'client.lua'