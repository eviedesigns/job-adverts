RegisterCommand(Config.Command, function()
    local input = lib.inputDialog('Business Advertisement', {
        {
            type = 'textarea',
            label = 'Advert Message',
            description = 'Type the message you want to send to the whole server.',
            placeholder = 'We are now open! Come visit us!',
            required = true,
            min = 5,
            max = Config.MaxMessageLength
        }
    })

    if not input then return end

    local message = input[1]
    if not message or message == '' then return end

    TriggerServerEvent('evie_job_adverts:server:sendAdvert', message)
end, false)

RegisterNetEvent('evie_job_adverts:client:showAdvert', function(business, message)
    lib.notify({
        id = 'business_advert',
        title = business,
        description = message,
        duration = 15000,
        position = 'top',
        type = 'inform'
    })
end)

RegisterNetEvent('evie_job_adverts:client:notify', function(message, notifyType)
    lib.notify({
        title = 'Business Advertisement',
        description = message,
        type = notifyType or 'inform',
        position = Config.NotificationPosition
    })
end)