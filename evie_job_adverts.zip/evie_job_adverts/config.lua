Config = {}

Config.Framework = 'auto' -- auto, qbox, qbcore, esx

Config.Command = 'ad'
Config.CooldownMinutes = 10
Config.MaxMessageLength = 150
Config.AdvertDuration = 15000
Config.NotificationPosition = 'top-right' -- 'top' 'top-right' 'top-left' 'bottom' 'bottom-right' 'bottom-left' 'center-right' 'center-left'

Config.AllowedJobs = {
    ['burgershot'] = {
        label = 'Burger Shot',
        icon = '🍔'
    },

    ['mechanic'] = {
        label = 'Hayes Auto',
        icon = '🔧'
    },

    ['bahamas'] = {
        label = 'Bahama Mamas',
        icon = '🍹'
    }
}

Config.ChatPrefix = 'Business Advertisement'
Config.ChatColor = { 255, 180, 0 }