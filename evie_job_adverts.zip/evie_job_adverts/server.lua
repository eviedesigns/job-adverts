local cooldowns = {}

local function getPlayerJob(src)
    if Config.Framework == 'qbox' or GetResourceState('qbx_core') == 'started' then
        local player = exports.qbx_core:GetPlayer(src)
        if player and player.PlayerData and player.PlayerData.job then
            return player.PlayerData.job.name
        end
    end

    if Config.Framework == 'qbcore' or GetResourceState('qb-core') == 'started' then
        local QBCore = exports['qb-core']:GetCoreObject()
        local player = QBCore.Functions.GetPlayer(src)
        if player and player.PlayerData and player.PlayerData.job then
            return player.PlayerData.job.name
        end
    end

    if Config.Framework == 'esx' or GetResourceState('es_extended') == 'started' then
        local ESX = exports.es_extended:getSharedObject()
        local player = ESX.GetPlayerFromId(src)
        if player and player.job then
            return player.job.name
        end
    end

    return nil
end

local function notify(src, msg, notifyType)
    TriggerClientEvent(
        'evie_job_adverts:client:notify',
        src,
        msg,
        notifyType or 'inform'
    )
end

RegisterNetEvent('evie_job_adverts:server:sendAdvert', function(message)
    local src = source
    local job = getPlayerJob(src)

    if not job or not Config.AllowedJobs[job] then
        notify(src, 'You are not allowed to send business advertisements.', 'error')
        return
    end

    if type(message) ~= 'string' or message == '' then
        notify(src, 'You must enter an advert message.', 'error')
        return
    end

    if #message > Config.MaxMessageLength then
        notify(src, 'Your advert is too long.', 'error')
        return
    end

    local currentTime = os.time()
    local cooldownTime = Config.CooldownMinutes * 60

    if cooldowns[job] and currentTime < cooldowns[job] then
        local remaining = cooldowns[job] - currentTime

        local minutes = math.floor(remaining / 60)
        local seconds = remaining % 60

        local timeLeft

        if minutes > 0 then
            timeLeft = string.format('%dm %02ds', minutes, seconds)
        else
            timeLeft = string.format('%ds', seconds)
        end

        notify(src, ('You can advertise again in %s.'):format(timeLeft), 'error')
        return
    end

    cooldowns[job] = currentTime + cooldownTime

    local business = Config.AllowedJobs[job]

    TriggerClientEvent(
        'evie_job_adverts:client:showAdvert',
        -1,
        business.label,
        message
    )

    notify(src, 'Business advert sent.', 'success')
end)